import { Btn } from "./ui/Btn";

const HOW_STEPS = [
  {
    n: "01", icon: "✏️", color: "#3B82F6", bg: "#EFF6FF",
    title: "Răspunde la întrebări",
    desc: "Alegi un test, apoi răspunzi sincer la întrebările lui.",
  },
  {
    n: "02", icon: "🔍", color: "#A855F7", bg: "#FAF5FF",
    title: "Descoperă-ți profilul",
    desc: "Primești un profil clar, construit din răspunsurile tale.",
  },
  {
    n: "03", icon: "🗺️", color: "#22C55E", bg: "#F0FFF4",
    title: "Explorează posibilitățile",
    desc: "Vei vedea domenii și cariere care ți se potrivesc și te pot inspira.",
  },
];

export function HowItWorksModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 animate-modal-overlay" style={{ backgroundColor: "rgba(0,0,0,0.45)" }}>
      {/* Overlay click */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Card */}
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-7 sm:p-10 animate-modal-card overflow-y-auto max-h-[90vh]">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 flex items-center justify-center rounded-full bg-[#f7f7f7] text-[#777] hover:bg-[#e5e5e5] hover:text-[#3c3c3c] font-black text-base transition-colors"
        >
          ✕
        </button>

        <div className="text-3xl mb-3">🧭</div>
        <h2 className="text-2xl font-black text-[#3c3c3c]">Cum funcționează?</h2>
        <p className="mt-1 text-sm text-[#777] font-bold">Trei pași spre mai multă claritate</p>

        <div className="mt-7 space-y-4">
          {HOW_STEPS.map(({ n, icon, color, bg, title, desc }) => (
            <div key={n} className="flex gap-4 items-start rounded-2xl p-4 border-2" style={{ borderColor: color + "33", backgroundColor: bg }}>
              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 shadow-sm" style={{ backgroundColor: color + "20", border: `2px solid ${color}40` }}>
                {icon}
              </div>
              <div>
                <div className="text-xs font-black mb-0.5" style={{ color: color }}>{n}</div>
                <h3 className="font-black text-[#3c3c3c] text-base leading-tight">{title}</h3>
                <p className="mt-1 text-sm text-[#777] font-semibold leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        <Btn onClick={onClose} size="lg" className="w-full mt-7">
          Am înțeles 👍
        </Btn>
      </div>
    </div>
  );
}
