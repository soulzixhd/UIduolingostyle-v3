import type { ReactNode } from "react";
import { cn } from "../../lib/cn";

type BtnVariant = "primary" | "outline" | "ghost";
type BtnSize = "sm" | "md" | "lg";

export function Btn({
  children,
  onClick,
  disabled = false,
  variant = "primary",
  size = "md",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: BtnVariant;
  size?: BtnSize;
  className?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 font-extrabold rounded-2xl transition-all duration-75 select-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none disabled:translate-y-0";
  const sizes: Record<BtnSize, string> = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };
  const variants: Record<BtnVariant, string> = {
    primary: "bg-[#58CC02] text-white shadow-[0_4px_0_#46A302] hover:shadow-[0_2px_0_#46A302] hover:translate-y-0.5 active:shadow-none active:translate-y-1",
    outline: "bg-white text-[#58CC02] border-2 border-[#58CC02] shadow-[0_4px_0_#b8e888] hover:shadow-[0_2px_0_#b8e888] hover:translate-y-0.5 active:shadow-none active:translate-y-1",
    ghost: "bg-transparent text-[#777] hover:bg-[#f7f7f7] hover:text-[#3c3c3c]",
  };
  return (
    <button className={cn(base, sizes[size], variants[variant], className)} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}
