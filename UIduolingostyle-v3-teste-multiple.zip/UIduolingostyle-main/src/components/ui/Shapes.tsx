// Reusable, test-agnostic animated background blobs used behind the
// questionnaire card. Four subtly different layouts, cycled by `variant`.
export function Shapes({ s1, s2, variant }: { s1: string; s2: string; variant: number }) {
  const v = variant % 4;
  if (v === 0)
    return (
      <>
        <div style={{ position: "absolute", inset: 0, top: "-70px", right: "-60px", width: "320px", height: "320px", background: s1, borderRadius: "67% 33% 58% 42% / 43% 55% 45% 57%" }} />
        <div style={{ position: "absolute", bottom: "50px", left: "-50px", width: "200px", height: "200px", background: s2, borderRadius: "42% 58% 70% 30% / 60% 40% 60% 40%" }} />
        <div style={{ position: "absolute", top: "42%", left: "6%", width: "90px", height: "90px", background: s1, borderRadius: "50%" }} />
      </>
    );
  if (v === 1)
    return (
      <>
        <div style={{ position: "absolute", top: "-55px", left: "12%", width: "260px", height: "260px", background: s2, borderRadius: "30% 70% 40% 60% / 50% 30% 70% 50%" }} />
        <div style={{ position: "absolute", bottom: "-50px", right: "-40px", width: "220px", height: "220px", background: s1, borderRadius: "70% 30% 50% 50% / 30% 60% 40% 70%" }} />
        <div style={{ position: "absolute", bottom: "0", left: "50%", transform: "translateX(-50%)", width: "110px", height: "280px", background: s2, borderRadius: "50% 50% 0 0 / 80% 80% 0 0" }} />
      </>
    );
  if (v === 2)
    return (
      <>
        <div style={{ position: "absolute", top: "50px", right: "-55px", width: "290px", height: "190px", background: s1, borderRadius: "50% 50% 40% 60% / 60% 40% 60% 40%" }} />
        <div style={{ position: "absolute", top: "-35px", left: "-35px", width: "170px", height: "170px", background: s2, borderRadius: "50%" }} />
        <div style={{ position: "absolute", bottom: "-80px", left: "18%", width: "270px", height: "270px", background: s1, borderRadius: "60% 40% 30% 70% / 50% 60% 40% 50%" }} />
      </>
    );
  // variant 3
  return (
    <>
      <div style={{ position: "absolute", bottom: "-65px", right: "-80px", width: "360px", height: "260px", background: s2, borderRadius: "70% 30% 60% 40% / 40% 60% 40% 60%" }} />
      <div style={{ position: "absolute", top: "20%", left: "-25px", width: "150px", height: "150px", background: s1, borderRadius: "40% 60% 70% 30% / 50% 40% 60% 50%" }} />
      <div style={{ position: "absolute", top: "8%", right: "18%", width: "85px", height: "85px", background: s2, borderRadius: "50%" }} />
    </>
  );
}
