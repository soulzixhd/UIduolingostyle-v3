import type { ReactNode } from "react";
import { cn } from "../../lib/cn";

export function Logo({ onClick, light = false }: { onClick?: () => void; light?: boolean }) {
  return (
    <button onClick={onClick} className={cn("flex items-center gap-2.5 font-black text-xl hover:opacity-80 transition-opacity", light ? "text-white" : "text-[#3c3c3c]")}>
      <div className="w-10 h-10 bg-[#58CC02] rounded-xl flex items-center justify-center text-white font-black text-lg shadow-[0_3px_0_#46A302]">M</div>
      <span className="hidden sm:block">Mai departe</span>
    </button>
  );
}

export function Tag({ children }: { children: ReactNode }) {
  return <span className="text-xs font-bold px-2.5 py-1 bg-[#f7f7f7] text-[#777] rounded-lg border border-[#e5e5e5]">{children}</span>;
}
