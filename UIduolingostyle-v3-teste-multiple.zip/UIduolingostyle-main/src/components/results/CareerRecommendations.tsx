import type { Career } from "../../types";
import { Btn } from "../ui/Btn";
import { Tag } from "../ui/Logo";

export function CareerRecommendations({
  careers,
  onCareer,
}: {
  careers: Career[];
  onCareer: (c: Career) => void;
}) {
  return (
    <section id="recomandari" className="max-w-5xl mx-auto px-5 sm:px-8 py-14 scroll-mt-8">
      <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Ce ți s-ar putea potrivi?</p>
      <h2 className="mt-3 text-2xl sm:text-3xl font-black text-[#3c3c3c]">Direcții care s-ar putea potrivi profilului tău</h2>
      <p className="mt-1 text-sm text-[#777] font-semibold">Nu sunt singurele opțiuni. Deschide-le pe cele care îți stârnesc curiozitatea.</p>
      <div className="mt-8 grid md:grid-cols-3 gap-4">
        {careers.map((career) => (
          <div key={career.id} className="bg-white rounded-3xl border-2 border-[#E5E5E5] p-6 flex flex-col hover:border-[#58CC02] transition-colors duration-200">
            <div className="text-xs font-black text-[#afafaf] uppercase tracking-wider">{career.field}</div>
            <h3 className="mt-2 text-xl font-black text-[#3c3c3c]">{career.title}</h3>
            <p className="mt-3 text-sm text-[#777] leading-relaxed font-semibold flex-1">{career.summary}</p>
            <p className="mt-3 text-xs text-[#afafaf] font-bold leading-relaxed">{career.why}</p>
            <div className="mt-4 flex flex-wrap gap-2">{career.tags.map((tag) => <Tag key={tag}>{tag}</Tag>)}</div>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {career.roles.slice(0, 3).map((role) => (
                <span key={role} className="text-[11px] font-bold text-[#58CC02] bg-[#F0FFF4] px-2 py-1 rounded-lg">{role}</span>
              ))}
            </div>
            <Btn onClick={() => onCareer(career)} size="sm" variant="outline" className="mt-5 w-full">Explorează →</Btn>
          </div>
        ))}
      </div>
      <div className="mt-10 bg-[#EFF6FF] border-2 border-[#BFDBFE] rounded-2xl p-5 flex gap-3 items-start">
        <span className="text-xl shrink-0">💡</span>
        <p className="text-sm text-[#1D4ED8] font-bold leading-relaxed">
          <strong>De reținut:</strong> Rezultatul este un punct de plecare pentru explorarea carierei. Nu există o singură carieră potrivită pentru tine.
        </p>
      </div>
    </section>
  );
}
