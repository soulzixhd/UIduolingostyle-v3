export function ResultHero({
  code,
  topNames,
  introText,
}: {
  code: string;
  topNames: string[];
  introText: string;
}) {
  return (
    <section className="bg-[#F0FFF4] border-b-2 border-[#BBF7D0] px-5 py-16 sm:py-20">
      <div className="max-w-5xl mx-auto">
        <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Iată ce am descoperit despre tine</p>
        <div className="mt-4 grid gap-6 lg:grid-cols-[auto_1fr] lg:items-end">
          <div>
            <div className="text-7xl sm:text-8xl font-black text-[#58CC02] tracking-widest leading-none">{code}</div>
            <p className="mt-3 font-extrabold text-[#3c3c3c] text-base">{topNames.join(" · ")}</p>
          </div>
          <p className="max-w-2xl text-xl sm:text-2xl font-black text-[#3c3c3c] leading-snug">{introText}</p>
        </div>
      </div>
    </section>
  );
}
