import type { Dimension } from "../../types";

export function DimensionScores({
  dimensions,
  scores,
  top,
  scoreToPercent,
}: {
  dimensions: Dimension[];
  scores: Record<string, number>;
  top: string[];
  scoreToPercent: (score: number) => number;
}) {
  return (
    <section className="max-w-5xl mx-auto px-5 sm:px-8 py-14">
      <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Cum arată profilul tău</p>
      <h2 className="mt-3 text-2xl sm:text-3xl font-black text-[#3c3c3c]">Cele șase laturi ale profilului tău</h2>
      <p className="mt-1 text-sm text-[#777] font-semibold">Un scor mai mare arată că acele activități îți trezesc mai des interesul.</p>
      <div className="mt-8 space-y-5">
        {dimensions.map((dim) => {
          const pct = scoreToPercent(scores[dim.code]);
          const isTop = top.includes(dim.code);
          return (
            <div key={dim.code}>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-black shrink-0 shadow-sm" style={{ backgroundColor: dim.color }}>
                  {dim.code}
                </div>
                <span className="font-extrabold text-[#3c3c3c] text-sm flex-1">{dim.name}</span>
                {isTop && (
                  <span className="text-xs font-black px-2 py-0.5 rounded-full border" style={{ backgroundColor: dim.bg, color: dim.color, borderColor: dim.color + "40" }}>
                    Top {top.indexOf(dim.code) + 1}
                  </span>
                )}
                <span className="text-sm font-black text-[#3c3c3c] min-w-[2.5rem] text-right">{pct}%</span>
              </div>
              <div className="h-4 bg-[#E5E5E5] rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${pct}%`, backgroundColor: dim.color }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Codul Holland + top 3 explicate */}
      <div className="mt-10 bg-[#F7F7F7] border-2 border-[#E5E5E5] rounded-3xl p-6 sm:p-8">
        <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Codul tău Holland</p>
        <h3 className="mt-2 text-xl font-black text-[#3c3c3c]">Primele tale trei direcții</h3>
        <div className="mt-6 grid md:grid-cols-3 gap-4">
          {top.map((c, i) => {
            const dim = dimensions.find((d) => d.code === c)!;
            return (
              <div key={c} className="bg-white rounded-3xl p-6 border-2" style={{ borderColor: dim.color }}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-lg mb-4 shadow-sm" style={{ backgroundColor: dim.color }}>
                  {dim.code}
                </div>
                <div className="text-xs font-black text-[#afafaf] mb-1">#{i + 1}</div>
                <h4 className="text-xl font-black text-[#3c3c3c]">{dim.name}</h4>
                <p className="mt-2 text-sm text-[#777] leading-relaxed font-semibold">{dim.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
