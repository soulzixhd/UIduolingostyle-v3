import { Btn } from "../ui/Btn";

export function ExploreMore({
  onRetake,
  onOtherTest,
}: {
  onRetake: () => void;
  onOtherTest: () => void;
}) {
  const scrollToCareers = () => {
    document.getElementById("recomandari")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="border-t-2 border-[#E5E5E5] px-5 py-16 text-center">
      <div className="text-4xl mb-4">🔭</div>
      <h2 className="text-2xl sm:text-3xl font-black text-[#3c3c3c]">Vrei să afli mai multe?</h2>
      <p className="mt-2 text-[#777] font-bold text-sm max-w-md mx-auto">
        Rezultatul e un început, nu o destinație. Continuă să explorezi în ritmul tău.
      </p>
      <div className="mt-7 flex flex-col sm:flex-row gap-3 justify-center">
        <Btn onClick={scrollToCareers} size="md">🧭 Explorează cariere</Btn>
        <Btn variant="outline" onClick={onOtherTest} size="md">🔀 Încearcă alt test</Btn>
        <Btn variant="ghost" onClick={onRetake} size="md">🔄 Refă testul</Btn>
      </div>
    </section>
  );
}
