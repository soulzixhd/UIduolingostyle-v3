export function ProfileNarrative({ paragraphs }: { paragraphs: string[] }) {
  if (paragraphs.length === 0) return null;
  return (
    <section className="bg-[#F7F7F7] border-y-2 border-[#E5E5E5] px-5 py-14">
      <div className="max-w-4xl mx-auto">
        <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Dincolo de scoruri</p>
        <h2 className="mt-3 text-2xl sm:text-3xl font-black text-[#3c3c3c]">Cum ai putea fi</h2>
        <div className="mt-6 space-y-4">
          {paragraphs.map((p, i) => (
            <p key={i} className="text-base sm:text-lg text-[#3c3c3c] leading-relaxed font-semibold">
              {p}
            </p>
          ))}
        </div>
        <div className="mt-6 bg-white border-2 border-[#E5E5E5] rounded-2xl px-5 py-4 flex gap-3 items-start">
          <span className="text-base shrink-0">🌱</span>
          <p className="text-sm text-[#777] font-bold leading-relaxed">
            Aceasta este o orientare, nu un verdict. Te poți regăsi parțial, complet sau deloc — și e complet în regulă.
          </p>
        </div>
      </div>
    </section>
  );
}
