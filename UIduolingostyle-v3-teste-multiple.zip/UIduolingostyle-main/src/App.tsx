import { useMemo, useState } from "react";
import type { Career, Screen } from "./types";
import { testCatalog, getTestById } from "./data/testCatalog";
import type { RiasecScores } from "./data/riasec";

import { Landing } from "./screens/Landing";
import { TestSelection } from "./screens/TestSelection";
import { TestIntro } from "./screens/TestIntro";
import { Questionnaire } from "./screens/Questionnaire";
import { Completion } from "./screens/Completion";
import { Results } from "./screens/Results";
import { CareerDetail } from "./screens/CareerDetail";

export default function App() {
  const [screen, setScreen] = useState<Screen>("landing");
  const [testId, setTestId] = useState<string | null>(null);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [career, setCareer] = useState<Career | null>(null);

  const activeTest = testId ? getTestById(testId) : undefined;

  const scores = useMemo(() => {
    if (!activeTest) return null;
    return activeTest.computeScores(answers);
  }, [activeTest, answers]);

  const go = (next: Screen) => { setScreen(next); window.scrollTo({ top: 0 }); };

  const startSelection = () => go("test-selection");

  const selectTest = (id: string) => {
    setTestId(id);
    setAnswers({});
    setCurrent(0);
    setCareer(null);
    go("test-intro");
  };

  const retake = () => {
    setAnswers({});
    setCurrent(0);
    setCareer(null);
    go("test-intro");
  };

  if (screen === "landing") return <Landing onStart={startSelection} />;

  if (screen === "test-selection")
    return <TestSelection tests={testCatalog} onSelect={selectTest} onBack={() => go("landing")} />;

  if (screen === "test-intro" && activeTest)
    return <TestIntro test={activeTest} onStart={() => go("questionnaire")} onBack={startSelection} />;

  if (screen === "questionnaire" && activeTest)
    return (
      <Questionnaire
        test={activeTest}
        answers={answers}
        current={current}
        onAnswer={(value) => {
          const q = activeTest.questions[current];
          if (q) setAnswers((prev) => ({ ...prev, [q.id]: value }));
        }}
        onBack={() => (current ? setCurrent(current - 1) : go("test-intro"))}
        onNext={() => (current < activeTest.questions.length - 1 ? setCurrent(current + 1) : go("completion"))}
      />
    );

  if (screen === "completion") return <Completion onShow={() => go("results")} />;

  if (screen === "career" && career) return <CareerDetail career={career} onBack={() => go("results")} />;

  if (screen === "results" && activeTest && scores) {
    // Currently only RIASEC exists; when a second test is added, branch here
    // on activeTest.meta.id and render that test's own Results screen —
    // each test keeps its own results/interpretation, as required.
    if (activeTest.meta.id === "riasec") {
      return (
        <Results
          scores={scores as RiasecScores}
          onRetake={retake}
          onOtherTest={startSelection}
          onCareer={(c) => { setCareer(c); go("career"); }}
        />
      );
    }
  }

  return <Landing onStart={startSelection} />;
}
