// ── Shared, test-agnostic types ─────────────────────────────────────────────
// Every individual test (RIASEC, and any future test) implements these shapes
// so that UI components (Questionnaire, TestIntro, TestSelection...) can stay
// completely generic and reusable.

export type Screen =
  | "landing"
  | "test-selection"
  | "test-intro"
  | "questionnaire"
  | "completion"
  | "results"
  | "career";

/** One measured dimension of a test (e.g. RIASEC's "R", "I", "A"...). */
export interface Dimension {
  code: string;
  name: string;
  short: string;
  description: string;
  color: string;
  bg: string;
}

/** A single question belonging to a test. */
export interface Question {
  id: number;
  dimension: string;
  text: string;
}

/** A career / field recommendation that can be matched against dimension codes. */
export interface Career {
  id: string;
  title: string;
  field: string;
  codes: string[];
  summary: string;
  tags: string[];
  why: string;
  involves: string[];
  studies: string[];
  roles: string[];
  outlook: string;
}

/** Color theme for the animated background of a single question. */
export interface QuestionTheme {
  bg: string;
  s1: string;
  s2: string;
  isDark: boolean;
}

/** Metadata shown on the "Alege un test" selection card + the test intro screen. */
export interface TestMeta {
  id: string;
  name: string;
  shortDescription: string;
  whatItMeasures: string;
  whyUseful: string;
  howToAnswer: string;
  estimatedMinutes: string;
  questionCount: number;
  icon: string;
  color: string;
  bg: string;
  /** Set to false to show a test as "coming soon" (no real content yet). */
  available: boolean;
}

/** Everything one test needs to run: its own data, own scoring, own UI content. */
export interface TestDefinition<TScores extends Record<string, number> = Record<string, number>> {
  meta: TestMeta;
  dimensions: Dimension[];
  questions: Question[];
  answerLabels: string[];
  careers: Career[];
  computeScores: (answers: Record<number, number>) => TScores;
  getTopCodes: (scores: TScores, count?: number) => string[];
}
