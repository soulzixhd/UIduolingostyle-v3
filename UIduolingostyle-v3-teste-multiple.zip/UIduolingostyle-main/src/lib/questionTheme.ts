import type { QuestionTheme } from "../types";

/**
 * Computes the animated background theme for a question, based on how far
 * the user has progressed through the questionnaire (0 = first question,
 * 1 = last question). Works for any test — it only needs a progress ratio,
 * never anything RIASEC-specific.
 *
 * Journey: deep indigo → violet → magenta → rose → warm peach.
 * The background goes from darker to lighter as progress increases, so the
 * user *feels* themselves moving forward, whichever test they're taking.
 */
export function getQuestionTheme(index: number, total: number): QuestionTheme {
  const t = index / Math.max(total - 1, 1);
  const hue = 250 + t * 140; // 250 → 390 (wraps to 30)
  const bgL = 12 + t * 72; // 12% → 84% lightness
  const bgS = 65 + t * 5; // 65% → 70% saturation
  return {
    bg: `hsl(${hue}, ${bgS}%, ${bgL}%)`,
    s1: `hsla(${hue - 18}, 80%, ${Math.min(bgL + 14, 94)}%, 0.38)`,
    s2: `hsla(${hue + 22}, 70%, ${Math.min(bgL + 26, 97)}%, 0.26)`,
    isDark: bgL < 50,
  };
}
