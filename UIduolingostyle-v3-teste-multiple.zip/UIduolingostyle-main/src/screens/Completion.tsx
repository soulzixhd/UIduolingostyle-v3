import { Btn } from "../components/ui/Btn";

export function Completion({ onShow }: { onShow: () => void }) {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-5 py-12">
      <div className="max-w-md w-full text-center animate-bounce-in">
        <div className="text-8xl mb-6">🎉</div>
        <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Ai terminat!</p>
        <h1 className="mt-3 text-4xl sm:text-5xl font-black text-[#3c3c3c]">Profilul tău e gata.</h1>
        <p className="mt-5 text-base text-[#777] leading-relaxed font-semibold max-w-sm mx-auto">
          Am pus cap la cap răspunsurile tale. Urmează câteva direcții de explorat — nu o decizie pe care trebuie să o iei acum.
        </p>
        <div className="mt-8 bg-[#F0FFF4] border-2 border-[#BBF7D0] rounded-2xl p-6">
          <div className="text-3xl mb-2">🌱</div>
          <p className="font-extrabold text-[#166534] text-sm">
            Acesta este un punct de plecare. Explorarea ta continuă de aici.
          </p>
        </div>
        <Btn onClick={onShow} size="lg" className="mt-8 w-full">🗺️ Vezi profilul meu</Btn>
      </div>
    </div>
  );
}
