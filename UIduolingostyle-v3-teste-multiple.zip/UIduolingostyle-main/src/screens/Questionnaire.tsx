import { useState } from "react";
import type { TestDefinition } from "../types";
import { cn } from "../lib/cn";
import { getQuestionTheme } from "../lib/questionTheme";
import { Shapes } from "../components/ui/Shapes";
import { Btn } from "../components/ui/Btn";

export function Questionnaire({
  test,
  answers,
  current,
  onAnswer,
  onNext,
  onBack,
}: {
  test: TestDefinition;
  answers: Record<number, number>;
  current: number;
  onAnswer: (v: number) => void;
  onNext: () => void;
  onBack: () => void;
}) {
  const [direction, setDirection] = useState<"forward" | "back">("forward");
  const { questions, answerLabels } = test;

  const question = questions[current];
  if (!question) return null;

  const selected = answers[question.id];
  const progress = ((current + 1) / questions.length) * 100;
  const isLast = current === questions.length - 1;
  const theme = getQuestionTheme(current, questions.length);
  const variant = current % 4;

  const handleNext = () => { setDirection("forward"); onNext(); };
  const handleBack = () => { setDirection("back"); onBack(); };

  return (
    <div
      className="min-h-screen flex flex-col relative overflow-hidden"
      style={{ backgroundColor: theme.bg, transition: "background-color 700ms ease" }}
    >
      {/* Animated background shapes — darker at the start, lighter as the
          user progresses, so momentum is felt visually for any test. */}
      <div key={`shapes-${current}`} className="absolute inset-0 pointer-events-none overflow-hidden animate-shapes-enter">
        <Shapes s1={theme.s1} s2={theme.s2} variant={variant} />
      </div>

      {/* Progress bar header */}
      <div className="relative z-10 px-4 pt-5 pb-3 sm:px-6">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <button
            onClick={handleBack}
            className="w-9 h-9 flex items-center justify-center rounded-full font-black text-sm transition-all shrink-0"
            style={{ background: "rgba(255,255,255,0.2)", color: theme.isDark ? "rgba(255,255,255,0.8)" : "rgba(0,0,0,0.5)" }}
            onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "rgba(255,255,255,0.32)"; }}
            onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "rgba(255,255,255,0.2)"; }}
          >
            ✕
          </button>

          <div className="flex-1 h-3.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.25)" }}>
            <div
              className="h-full rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%`, background: theme.isDark ? "rgba(255,255,255,0.9)" : "#58CC02" }}
            />
          </div>

          <span
            className="text-sm font-black shrink-0 min-w-[3rem] text-right"
            style={{ color: theme.isDark ? "rgba(255,255,255,0.85)" : "rgba(0,0,0,0.55)" }}
          >
            {current + 1}/{questions.length}
          </span>
        </div>
      </div>

      {/* Question card */}
      <div className="relative z-10 flex-1 px-4 pb-6 pt-4 sm:px-6 flex items-start sm:items-center justify-center">
        <div
          key={`card-${current}`}
          className={cn(
            "w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 sm:p-8",
            direction === "forward" ? "animate-card-right" : "animate-card-left"
          )}
        >
          <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest mb-4">
            Alege varianta care te reprezintă
          </p>
          <h1 className="text-xl sm:text-2xl font-black text-[#3c3c3c] leading-snug mb-6">
            {question.text}
          </h1>

          <fieldset className="space-y-2.5">
            <legend className="sr-only">Selectează un răspuns</legend>
            {answerLabels.map((label, index) => {
              const value = index + 1;
              const isSelected = selected === value;
              return (
                <button
                  key={label}
                  type="button"
                  aria-pressed={isSelected}
                  onClick={() => onAnswer(value)}
                  className={cn(
                    "w-full flex items-center gap-3.5 p-3.5 rounded-2xl border-2 text-left transition-all duration-150 cursor-pointer",
                    isSelected
                      ? "border-[#58CC02] bg-[#F0FFF4] shadow-[0_2px_0_#b8f5b8]"
                      : "border-[#E5E5E5] bg-white hover:border-[#93C5FD] hover:bg-[#EFF6FF]"
                  )}
                >
                  <span
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-sm font-black shrink-0 transition-all",
                      isSelected
                        ? "bg-[#58CC02] text-white shadow-[0_2px_0_#46A302]"
                        : "bg-[#F7F7F7] text-[#afafaf] border-2 border-[#E5E5E5]"
                    )}
                  >
                    {isSelected ? "✓" : value}
                  </span>
                  <span className={cn("flex-1 font-extrabold text-sm", isSelected ? "text-[#166534]" : "text-[#3c3c3c]")}>
                    {label}
                  </span>
                  {isSelected && <span className="text-[#58CC02] font-black text-base shrink-0">●</span>}
                </button>
              );
            })}
          </fieldset>

          <div className="mt-6 space-y-2">
            <Btn onClick={handleNext} disabled={!selected} size="lg" className="w-full">
              {isLast ? "🎯 Vezi rezultatul" : "Continuă →"}
            </Btn>
            {!selected && (
              <p className="text-center text-xs text-[#afafaf] font-bold">Alege o variantă pentru a continua.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
