import type { TestDefinition } from "../types";
import { Btn } from "../components/ui/Btn";
import { Logo } from "../components/ui/Logo";

export function TestSelection({
  tests,
  onSelect,
  onBack,
}: {
  tests: TestDefinition[];
  onSelect: (testId: string) => void;
  onBack: () => void;
}) {
  return (
    <div className="min-h-screen bg-white">
      <header className="max-w-4xl mx-auto w-full flex items-center justify-between px-5 py-5 sm:px-8">
        <Logo onClick={onBack} />
        <Btn variant="ghost" onClick={onBack} size="sm">← Înapoi</Btn>
      </header>

      <section className="max-w-4xl mx-auto px-5 sm:px-8 pt-8 pb-20">
        <div className="max-w-xl">
          <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Care parte din tine vrei să o descoperi?</p>
          <h1 className="mt-3 text-3xl sm:text-4xl font-black text-[#3c3c3c] leading-tight">Alege un test</h1>
          <p className="mt-3 text-base text-[#777] leading-relaxed font-semibold">
            Descoperă mai multe despre tine și despre direcțiile care ți s-ar putea potrivi.
          </p>
        </div>

        <div className="mt-10 grid sm:grid-cols-2 gap-5">
          {tests.map((test) => {
            const { meta } = test;
            return (
              <div
                key={meta.id}
                className="bg-white rounded-3xl border-2 border-[#E5E5E5] p-6 flex flex-col hover:border-[#58CC02] transition-colors duration-200"
              >
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0 shadow-sm"
                  style={{ backgroundColor: meta.bg, border: `2px solid ${meta.color}40` }}
                >
                  {meta.icon}
                </div>
                <h2 className="mt-4 text-xl font-black text-[#3c3c3c]">{meta.name}</h2>
                <p className="mt-2 text-sm text-[#777] leading-relaxed font-semibold flex-1">{meta.shortDescription}</p>
                <p className="mt-3 text-xs text-[#afafaf] font-bold leading-relaxed">{meta.whatItMeasures}</p>

                <div className="mt-5 flex flex-wrap gap-2">
                  <span className="text-xs font-black px-2.5 py-1 rounded-full border" style={{ backgroundColor: meta.bg, color: meta.color, borderColor: meta.color + "40" }}>
                    ⏱️ {meta.estimatedMinutes}
                  </span>
                  <span className="text-xs font-black px-2.5 py-1 rounded-full bg-[#f7f7f7] text-[#777] border border-[#e5e5e5]">
                    {meta.questionCount} întrebări
                  </span>
                </div>

                <Btn onClick={() => onSelect(meta.id)} size="md" className="mt-6 w-full">
                  Începe testul →
                </Btn>
              </div>
            );
          })}

          {/* Placeholder card, shown so the grid never feels like a dead end —
              swapped for a real card the moment a new test's data is added. */}
          <div className="rounded-3xl border-2 border-dashed border-[#E5E5E5] p-6 flex flex-col items-center justify-center text-center bg-[#FAFAFA]">
            <div className="text-3xl mb-3">✨</div>
            <p className="text-sm font-extrabold text-[#afafaf]">Mai vin și alte teste</p>
            <p className="mt-1 text-xs text-[#c7c7c7] font-bold">Revino curând pentru mai multe direcții de descoperit.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
