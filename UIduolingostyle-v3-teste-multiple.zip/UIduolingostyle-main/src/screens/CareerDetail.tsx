import type { Career } from "../types";
import { Btn } from "../components/ui/Btn";
import { Logo } from "../components/ui/Logo";

export function CareerDetail({ career, onBack }: { career: Career; onBack: () => void }) {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b-2 border-[#E5E5E5] px-5 py-5">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Logo />
          <Btn variant="ghost" onClick={onBack} size="sm">← Profilul meu</Btn>
        </div>
      </header>
      <section className="bg-[#F7F7F7] border-b-2 border-[#E5E5E5] px-5 py-14">
        <div className="max-w-4xl mx-auto">
          <div className="text-xs font-black text-[#afafaf] uppercase tracking-widest">{career.field} · Direcție de explorat</div>
          <h1 className="mt-4 text-4xl sm:text-6xl font-black text-[#3c3c3c] leading-tight">{career.title}</h1>
          <p className="mt-5 text-lg text-[#777] leading-relaxed font-semibold max-w-3xl">{career.summary}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {career.tags.map((tag) => (
              <span key={tag} className="px-3 py-1.5 bg-white border-2 border-[#E5E5E5] rounded-full text-sm font-extrabold text-[#3c3c3c]">{tag}</span>
            ))}
          </div>
        </div>
      </section>
      <section className="max-w-4xl mx-auto px-5 sm:px-8 py-14">
        <div className="border-l-4 border-[#58CC02] pl-5 mb-10">
          <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">De ce ți s-ar putea potrivi</p>
          <p className="mt-3 text-xl leading-relaxed text-[#3c3c3c] font-extrabold">{career.why}</p>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { title: "Ce presupune", items: career.involves, icon: "🎯" },
            { title: "Ce poți studia", items: career.studies, icon: "📚" },
            { title: "Exemple de roluri", items: career.roles, icon: "🧭" },
          ].map(({ title, items, icon }) => (
            <div key={title} className="bg-[#F7F7F7] rounded-3xl border-2 border-[#E5E5E5] p-6">
              <div className="text-2xl mb-4">{icon}</div>
              <h2 className="text-base font-black text-[#3c3c3c] mb-4">{title}</h2>
              <ul className="space-y-3">
                {items.map((item) => (
                  <li key={item} className="flex gap-2 text-sm text-[#777] font-semibold items-start">
                    <span className="text-[#58CC02] shrink-0 mt-0.5 font-black">✓</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-5 bg-[#F0FFF4] border-2 border-[#BBF7D0] rounded-2xl p-6 sm:p-8">
          <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Perspective profesionale</p>
          <p className="mt-3 text-[#3c3c3c] leading-relaxed font-extrabold">{career.outlook}</p>
        </div>
        <Btn onClick={onBack} variant="outline" size="lg" className="mt-10">← Înapoi la recomandări</Btn>
      </section>
    </div>
  );
}
