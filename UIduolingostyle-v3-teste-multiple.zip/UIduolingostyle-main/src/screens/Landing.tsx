import { useState } from "react";
import { Btn } from "../components/ui/Btn";
import { Logo } from "../components/ui/Logo";
import { HowItWorksModal } from "../components/HowItWorksModal";

export function Landing({ onStart }: { onStart: () => void }) {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="max-w-6xl mx-auto flex items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
        <Logo />
        <nav className="hidden md:flex items-center gap-6">
          <button onClick={() => setShowModal(true)} className="text-sm font-bold text-[#777] hover:text-[#3c3c3c] transition-colors">
            Cum funcționează
          </button>
          <a href="#despre-test" className="text-sm font-bold text-[#777] hover:text-[#3c3c3c] transition-colors">
            Despre test
          </a>
        </nav>
        <Btn onClick={onStart} size="md">Începe testul →</Btn>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-5 sm:px-8 lg:px-12 pt-8 pb-24 sm:pb-28 grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-[#FFF7ED] text-[#EA580C] font-extrabold text-xs px-3 py-1.5 rounded-full border border-[#FED7AA] mb-6">
            🎯 Orientare în ritmul tău
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-[56px] font-black text-[#3c3c3c] leading-[1.1] tracking-tight">
            Nu știi încă ce vrei<br />să faci{" "}
            <span className="text-[#58CC02]">mai departe?</span>
          </h1>
          <p className="mt-5 text-lg text-[#777] leading-relaxed max-w-lg font-semibold">
            Descoperă ce domenii și cariere s-ar putea potrivi cu interesele tale. Fără presiune, fără răspunsuri greșite.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <Btn onClick={onStart} size="lg">🚀 Începe testul</Btn>
            <Btn variant="outline" size="lg" onClick={() => setShowModal(true)}>
              Cum funcționează?
            </Btn>
          </div>
          <p className="mt-4 text-sm text-[#afafaf] font-bold">⏱️ 10–15 minute · fără cont necesar</p>
        </div>

        {/* Decorative path visual */}
        <div className="hidden lg:flex items-center justify-center">
          <div className="relative w-64 h-64">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-[#58CC02] rounded-2xl shadow-[0_5px_0_#46A302] flex items-center justify-center text-3xl z-10">
                🧭
              </div>
            </div>
            {[
              { label: "🔧 Tehnic", pos: "top-0 left-1/2 -translate-x-1/2", c: "#F97316", bg: "#FFF7ED" },
              { label: "💡 Idei", pos: "top-1/2 right-0 -translate-y-1/2", c: "#3B82F6", bg: "#EFF6FF" },
              { label: "🎨 Design", pos: "bottom-2 right-4", c: "#A855F7", bg: "#FAF5FF" },
              { label: "🤝 Oameni", pos: "bottom-2 left-4", c: "#EF4444", bg: "#FFF5F5" },
              { label: "📈 Business", pos: "top-1/2 left-0 -translate-y-1/2", c: "#22C55E", bg: "#F0FFF4" },
            ].map(({ label, pos, c, bg }) => (
              <div key={label} className={`absolute ${pos} px-3 py-2 rounded-xl font-extrabold text-xs border-2`} style={{ backgroundColor: bg, borderColor: c, color: c }}>
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reassurance — now the sole supporting section under the hero, since the
          "Trei pași" explainer lives only in the "Cum funcționează?" modal. */}
      <section id="despre-test" className="bg-[#F7F7F7] border-y-2 border-[#E5E5E5] px-5 py-20 sm:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <div className="text-5xl mb-5">✅</div>
          <h2 className="text-3xl sm:text-4xl font-black text-[#3c3c3c]">Nu există răspunsuri corecte sau greșite.</h2>
          <p className="mt-4 text-lg text-[#777] leading-relaxed max-w-xl mx-auto font-semibold">
            Alege ce te reprezintă acum. Rezultatul nu te pune într-o cutie — îți arată câteva direcții pe care merită să le explorezi.
          </p>
          <Btn onClick={onStart} size="lg" className="mt-8">Sunt gata să descopăr 🌟</Btn>
        </div>
      </section>

      <footer className="px-5 py-8 text-center text-sm text-[#afafaf] font-bold">
        Mai departe · Un punct bun de pornire.
      </footer>

      {showModal && <HowItWorksModal onClose={() => setShowModal(false)} />}
    </div>
  );
}
