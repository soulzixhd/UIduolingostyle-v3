import type { TestDefinition } from "../types";
import { Btn } from "../components/ui/Btn";
import { Logo } from "../components/ui/Logo";

export function TestIntro({
  test,
  onStart,
  onBack,
}: {
  test: TestDefinition;
  onStart: () => void;
  onBack: () => void;
}) {
  const { meta } = test;

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <header className="max-w-4xl mx-auto w-full flex items-center justify-between px-5 py-5 sm:px-8">
        <Logo onClick={onBack} />
        <Btn variant="ghost" onClick={onBack} size="sm">← Alte teste</Btn>
      </header>
      <section className="flex-1 flex items-center justify-center px-5 py-12 sm:px-8">
        <div className="max-w-lg w-full text-center animate-slide-up">
          <div className="text-6xl mb-4">{meta.icon}</div>
          <p className="text-[#afafaf] font-extrabold text-xs uppercase tracking-widest">Înainte să începem</p>
          <h1 className="mt-3 text-4xl sm:text-5xl font-black text-[#3c3c3c] leading-tight">{meta.name}</h1>
          <p className="mt-5 text-base text-[#777] leading-relaxed font-semibold max-w-sm mx-auto">{meta.whatItMeasures}</p>
          <p className="mt-3 text-sm text-[#777] leading-relaxed font-semibold max-w-sm mx-auto">{meta.whyUseful}</p>

          <div className="mt-10 grid grid-cols-3 gap-3">
            {[
              { val: String(meta.questionCount), label: "întrebări" },
              { val: meta.estimatedMinutes, label: "minute" },
              { val: "✓", label: "fără răspunsuri corecte" },
            ].map(({ val, label }) => (
              <div key={label} className="bg-[#F7F7F7] rounded-2xl p-4 border-2 border-[#E5E5E5]">
                <div className="text-xl font-black text-[#3c3c3c]">{val}</div>
                <div className="text-xs text-[#777] font-bold mt-1 leading-tight">{label}</div>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-[#FFF7ED] border-2 border-[#FED7AA] rounded-2xl px-5 py-4 text-sm text-[#C2410C] font-bold text-left flex gap-3 items-start">
            <span className="text-base shrink-0">💬</span>
            <span>{meta.howToAnswer}</span>
          </div>

          <Btn onClick={onStart} size="lg" className="mt-8 w-full">Începe 🚀</Btn>
        </div>
      </section>
    </div>
  );
}
