import { useMemo } from "react";
import type { Career } from "../types";
import { riasecDimensions } from "../data/riasec/dimensions";
import { riasecCareers } from "../data/riasec/careers";
import { riasecScoreToPercent, type RiasecScores } from "../data/riasec/scoring";
import { buildRiasecIntroNarrative, buildRiasecProfileNarrative } from "../data/riasec/narrative";
import { Btn } from "../components/ui/Btn";
import { Logo } from "../components/ui/Logo";
import { ResultHero } from "../components/results/ResultHero";
import { DimensionScores } from "../components/results/DimensionScores";
import { ProfileNarrative } from "../components/results/ProfileNarrative";
import { CareerRecommendations } from "../components/results/CareerRecommendations";
import { ExploreMore } from "../components/results/ExploreMore";

export function Results({
  scores,
  onCareer,
  onRetake,
  onOtherTest,
}: {
  scores: RiasecScores;
  onCareer: (c: Career) => void;
  onRetake: () => void;
  onOtherTest: () => void;
}) {
  const top = useMemo(
    () => [...riasecDimensions].sort((a, b) => scores[b.code] - scores[a.code]).slice(0, 3).map((d) => d.code),
    [scores]
  );
  const code = top.join("");
  const topNames = top.map((c) => riasecDimensions.find((d) => d.code === c)?.name ?? c);

  const introText = useMemo(() => buildRiasecIntroNarrative(top), [top]);
  const profileParagraphs = useMemo(() => buildRiasecProfileNarrative(top), [top]);

  const recommended = useMemo(
    () =>
      [...riasecCareers]
        .sort(
          (a, b) =>
            b.codes.reduce((t, c, i) => t + (top.includes(c) ? 3 - i : 0), 0) -
            a.codes.reduce((t, c, i) => t + (top.includes(c) ? 3 - i : 0), 0)
        )
        .slice(0, 3),
    [top]
  );

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b-2 border-[#E5E5E5] px-5 py-5">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Logo />
          <Btn variant="outline" onClick={onRetake} size="sm">🔄 Refă testul</Btn>
        </div>
      </header>

      <ResultHero code={code} topNames={topNames} introText={introText} />

      <DimensionScores dimensions={riasecDimensions} scores={scores} top={top} scoreToPercent={riasecScoreToPercent} />

      <ProfileNarrative paragraphs={profileParagraphs} />

      <CareerRecommendations careers={recommended} onCareer={onCareer} />

      <ExploreMore onRetake={onRetake} onOtherTest={onOtherTest} />
    </div>
  );
}
