import type { TestDefinition } from "../types";
import { riasecTest } from "./riasec";

// ── Test catalog ─────────────────────────────────────────────────────────────
// Every test the app can offer lives here. To add a new test:
//   1. Create src/data/<newTest>/ with its own dimensions, questions, careers,
//      scoring and meta — following the exact same shape as src/data/riasec/.
//   2. Import it here and add it to `testCatalog`.
// No screen component needs to change: TestSelection, TestIntro,
// Questionnaire and Results all work generically off a TestDefinition.
export const testCatalog: TestDefinition[] = [riasecTest];

export function getTestById(id: string): TestDefinition | undefined {
  return testCatalog.find((t) => t.meta.id === id);
}
