import { riasecDimensions } from "./dimensions";
import { riasecQuestions } from "./questions";

export type RiasecScores = Record<string, number>;

/** Sums up the 5-point answers for each of the 6 RIASEC dimensions. */
export function computeRiasecScores(answers: Record<number, number>): RiasecScores {
  return riasecDimensions.reduce((acc, d) => {
    const total = riasecQuestions
      .filter((q) => q.dimension === d.code)
      .reduce((sum, q) => sum + (answers[q.id] ?? 1), 0);
    return { ...acc, [d.code]: total };
  }, {} as RiasecScores);
}

/** Returns the top N dimension codes, highest score first. */
export function getTopRiasecCodes(scores: RiasecScores, count = 3): string[] {
  return [...riasecDimensions]
    .sort((a, b) => scores[b.code] - scores[a.code])
    .slice(0, count)
    .map((d) => d.code);
}

/** Converts a raw score (6 questions × 1–5) into a 0–100% bar width. */
export function riasecScoreToPercent(score: number): number {
  return Math.round(((score - 6) / 24) * 100);
}
