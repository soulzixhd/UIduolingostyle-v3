import type { Question } from "../../types";

type RiasecCode = "R" | "I" | "A" | "S" | "E" | "C";

const prompts: Record<RiasecCode, string[]> = {
  R: [
    "Îmi place să repar lucruri mecanice sau electronice.",
    "Mă atrag activitățile practice, în care construiesc ceva.",
    "Aș prefera să lucrez cu unelte sau echipamente.",
    "Îmi place să văd un rezultat concret al muncii mele.",
    "Mă simt bine când rezolv o problemă practică.",
    "Mi-ar plăcea să lucrez uneori în aer liber sau pe teren.",
  ],
  I: [
    "Îmi place să aflu de ce și cum funcționează lucrurile.",
    "Mă atrag problemele care cer logică și răbdare.",
    "Îmi place să caut informații înainte să trag o concluzie.",
    "Experimentele și descoperirile îmi stârnesc curiozitatea.",
    "Mă bucur când găsesc o explicație bună pentru ceva complicat.",
    "Aș lucra cu plăcere la o întrebare fără răspuns evident.",
  ],
  A: [
    "Îmi place să găsesc soluții originale, chiar dacă sunt neobișnuite.",
    "Mă atrag desenul, muzica, scrisul sau designul.",
    "Îmi place să îmi exprim ideile într-un mod personal.",
    "Observ detalii de culoare, formă sau stil.",
    "Prefer proiectele în care am libertate de creație.",
    "Îmi place să imaginez cum ar putea arăta ceva nou.",
  ],
  S: [
    "Îmi place să îi ajut pe ceilalți să înțeleagă ceva.",
    "Mă simt bine când lucrez împreună cu alți oameni.",
    "Prietenii apelează uneori la mine când au nevoie să vorbească.",
    "Mi-ar plăcea să contribui la binele unei comunități.",
    "Am răbdare să ascult puncte de vedere diferite.",
    "Mă motivează să văd că munca mea ajută pe cineva.",
  ],
  E: [
    "Îmi place să pornesc proiecte și să îi mobilizez pe ceilalți.",
    "Mă simt confortabil să îmi susțin ideile în fața unui grup.",
    "Mă atrag negocierile și găsirea unei soluții bune pentru toți.",
    "Îmi place să iau inițiativa când ceva trebuie organizat.",
    "Mă interesează cum cresc ideile în proiecte sau afaceri.",
    "Aș coordona cu plăcere o echipă pentru un scop comun.",
  ],
  C: [
    "Îmi place să pun informațiile într-o ordine clară.",
    "Mă simt bine când am un plan și pași concreți.",
    "Observ repede când lipsesc detalii importante.",
    "Îmi place să lucrez cu date, tabele sau liste.",
    "Prefer sarcinile în care știu ce rezultat este așteptat.",
    "Îmi place să fac un sistem mai simplu și mai eficient.",
  ],
};

const RIASEC_ORDER: RiasecCode[] = ["R", "I", "A", "S", "E", "C"];

export const riasecQuestions: Question[] = Array.from({ length: 6 }, (_, round) =>
  RIASEC_ORDER.map((dim) => ({ dimension: dim, text: prompts[dim][round] ?? "" }))
)
  .flat()
  .map((q, i) => ({ ...q, id: i + 1 }));

export const riasecAnswerLabels = ["Dezacord total", "Mai degrabă nu", "Neutru", "Mai degrabă da", "Acord total"];
