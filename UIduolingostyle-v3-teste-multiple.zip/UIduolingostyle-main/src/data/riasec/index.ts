import type { TestDefinition } from "../../types";
import { riasecDimensions } from "./dimensions";
import { riasecQuestions, riasecAnswerLabels } from "./questions";
import { riasecCareers } from "./careers";
import { riasecMeta } from "./meta";
import { computeRiasecScores, getTopRiasecCodes, type RiasecScores } from "./scoring";

export const riasecTest: TestDefinition<RiasecScores> = {
  meta: riasecMeta,
  dimensions: riasecDimensions,
  questions: riasecQuestions,
  answerLabels: riasecAnswerLabels,
  careers: riasecCareers,
  computeScores: computeRiasecScores,
  getTopCodes: getTopRiasecCodes,
};

export { riasecScoreToPercent } from "./scoring";
export { buildRiasecIntroNarrative, buildRiasecProfileNarrative } from "./narrative";
export { riasecTraits } from "./traits";
export type { RiasecScores } from "./scoring";
