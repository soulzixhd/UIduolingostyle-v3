// Per-dimension trait phrases used to build the personalized, human-sounding
// narrative on the results page ("Iată ce am descoperit despre tine" and
// "Cum ai putea fi"). Kept separate from scoring and from UI components.

export interface RiasecTraits {
  /** What kind of activities this dimension likes — used mid-sentence. */
  activities: string;
  /** What kind of environment feels comfortable — used mid-sentence. */
  environment: string;
  /** What kind of problems this dimension enjoys solving — used mid-sentence. */
  problems: string;
  /** What this dimension prefers working with (people / ideas / data / objects...). */
  worksWith: string;
  /** What tends to motivate this dimension — used mid-sentence. */
  motivation: string;
}

export const riasecTraits: Record<string, RiasecTraits> = {
  R: {
    activities: "activități practice și tehnice, în care poți construi sau repara ceva anume",
    environment: "un mediu în care lucrezi cu mâinile și vezi rezultate concrete",
    problems: "probleme tehnice, cu o soluție clară și palpabilă",
    worksWith: "obiecte, unelte și sisteme",
    motivation: "să vezi munca ta prinzând formă, într-un rezultat pe care îl poți atinge",
  },
  I: {
    activities: "activități de cercetare, analiză și rezolvare a unor probleme complexe",
    environment: "un mediu calm, în care poți gândi în profunzime și pune întrebări",
    problems: "probleme care cer logică, răbdare și o explicație bine fundamentată",
    worksWith: "idei, informații și date",
    motivation: "să înțelegi de ce și cum funcționează lucrurile cu adevărat",
  },
  A: {
    activities: "activități creative, în care te poți exprima într-un mod personal",
    environment: "un mediu flexibil, cu spațiu pentru originalitate și experimentare",
    problems: "provocări care nu au o singură soluție corectă",
    worksWith: "idei, forme și concepte originale",
    motivation: "să creezi ceva care poartă amprenta ta",
  },
  S: {
    activities: "activități în care poți ajuta, învăța sau colabora cu ceilalți",
    environment: "un mediu prietenos, construit pe comunicare și încredere",
    problems: "situații în care oamenii au nevoie de sprijin sau de o explicație clară",
    worksWith: "oameni",
    motivation: "să simți că munca ta contează pentru cineva anume",
  },
  E: {
    activities: "activități în care poți conduce, convinge și organiza",
    environment: "un mediu dinamic, orientat spre inițiativă și rezultate",
    problems: "provocări legate de organizare, strategie sau creșterea unei idei",
    worksWith: "oameni și proiecte",
    motivation: "să vezi o idee transformată în ceva real, cu impact",
  },
  C: {
    activities: "activități care presupun ordine, structură și atenție la detalii",
    environment: "un mediu organizat, cu așteptări și pași clari",
    problems: "situații în care informația trebuie pusă în ordine",
    worksWith: "date, informații și proceduri",
    motivation: "să faci un sistem mai clar, mai simplu și mai eficient",
  },
};
