import type { Dimension } from "../../types";

export const riasecDimensions: Dimension[] = [
  { code: "R", name: "Realistic", short: "Practic", description: "Practic, tehnic, orientat spre lucruri concrete.", color: "#F97316", bg: "#FFF7ED" },
  { code: "I", name: "Investigative", short: "Analitic", description: "Curios, analitic, atras de probleme și idei.", color: "#3B82F6", bg: "#EFF6FF" },
  { code: "A", name: "Artistic", short: "Creativ", description: "Creativ, expresiv, atras de design și idei noi.", color: "#A855F7", bg: "#FAF5FF" },
  { code: "S", name: "Social", short: "Empatic", description: "Orientat spre oameni, ajutor și colaborare.", color: "#EF4444", bg: "#FFF5F5" },
  { code: "E", name: "Enterprising", short: "Inițiativă", description: "Leadership, inițiativă, business și persuasiune.", color: "#22C55E", bg: "#F0FFF4" },
  { code: "C", name: "Conventional", short: "Organizat", description: "Organizare, structură, date și proceduri.", color: "#6366F1", bg: "#EEF2FF" },
];
