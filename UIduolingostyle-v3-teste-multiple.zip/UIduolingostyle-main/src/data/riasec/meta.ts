import type { TestMeta } from "../../types";
import { riasecQuestions } from "./questions";

export const riasecMeta: TestMeta = {
  id: "riasec",
  name: "Testul RIASEC",
  shortDescription: "Descoperă ce tip de activități, medii și probleme te atrag cel mai mult.",
  whatItMeasures: "Măsoară interesele tale pe 6 dimensiuni: Practic, Analitic, Creativ, Empatic, Inițiativă și Organizat.",
  whyUseful: "Te ajută să înțelegi ce fel de activități și domenii s-ar putea potrivi cu felul tău de a fi, ca punct de plecare în alegerea unei direcții.",
  howToAnswer: "Alege pentru fiecare afirmație varianta care te reprezintă cel mai bine — nu există răspunsuri corecte sau greșite.",
  estimatedMinutes: "10–15 minute",
  questionCount: riasecQuestions.length,
  icon: "🧭",
  color: "#58CC02",
  bg: "#F0FFF4",
  available: true,
};
