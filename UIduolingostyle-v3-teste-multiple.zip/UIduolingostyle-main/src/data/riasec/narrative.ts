import { riasecDimensions } from "./dimensions";
import { riasecTraits } from "./traits";

function traitsFor(codes: string[]) {
  return codes.map((c) => riasecTraits[c]).filter(Boolean);
}

function dimensionName(code: string): string {
  return riasecDimensions.find((d) => d.code === code)?.name ?? code;
}

/**
 * "Iată ce am descoperit despre tine" — a short, natural paragraph built
 * from the user's real top dimensions. Never the same two tests in a row
 * unless the profile really is the same.
 */
export function buildRiasecIntroNarrative(topCodes: string[]): string {
  const t = traitsFor(topCodes);
  if (t.length === 0) return "";

  const [first, second, third] = t;

  const parts: string[] = [];
  parts.push(`Răspunsurile tale indică o persoană care pare să se simtă bine atunci când face ${first.activities}.`);
  if (second) {
    parts.push(`Se pare că te atrag ${second.problems}, mai ales atunci când lucrezi în ${second.environment}.`);
  }
  if (third) {
    parts.push(`Pe lângă asta, ai putea fi motivat de dorința ${third.motivation}.`);
  }
  parts.push("Profilul tău sugerează o combinație de interese care merită explorată mai departe, nu o etichetă fixă.");

  return parts.join(" ");
}

/**
 * "Cum ai putea fi" — a longer, human description covering: preferred
 * activities, environment, kind of problems, who/what they like working
 * with, and what motivates them. Built entirely from the real profile.
 */
export function buildRiasecProfileNarrative(topCodes: string[]): string[] {
  const t = traitsFor(topCodes);
  if (t.length === 0) return [];

  const names = topCodes.map(dimensionName);
  const worksWith = Array.from(new Set(t.map((x) => x.worksWith))).join(" și ");

  return [
    `Este posibil să te simți atras de ${t[0].activities}${t[1] ? `, dar și de ${t[1].activities}` : ""}. Ai putea fi genul de persoană căreia îi place să lucreze cu ${worksWith}.`,
    `S-ar putea să te regăsești mai bine în ${t[0].environment}${t[1] ? `, sau în ${t[1].environment}` : ""}. Nu înseamnă că exclude restul — doar că acolo pare să curgă mai natural.`,
    `Ai putea fi atras de ${t[0].problems}${t[2] ? `, precum și de ${t[2].problems}` : ""}. Pe termen lung, ${t[0].motivation} pare să conteze cu adevărat pentru tine.`,
    `Toate acestea vin din combinația ${names.join(" – ")} din profilul tău — o direcție de plecare, nu o regulă strictă despre cine ești.`,
  ];
}
